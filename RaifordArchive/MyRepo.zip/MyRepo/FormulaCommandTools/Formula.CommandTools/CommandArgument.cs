﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Formula.CommandTools
{
    public class CommandArgument
    {
        public string Name { get; set; }
        public string Value { get; set; }   
    }
}
