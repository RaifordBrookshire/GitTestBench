﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Formula.CommandTools
{
    public class App
    {

       // public Console Console { get; set; }

    }
}
