﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KeeGen.Crypto.Bitcoin
{
    public class WalletInfo
    {
        public string Name { get; set; }
        public IList<string> Words { get; set; }
        public string   xPriv   { get; set; }
        public string xPub { get; set; }

        public IList<KeysInfo> Keys { get; set; } = new List<KeysInfo>();



    }
}
