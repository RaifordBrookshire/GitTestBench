﻿using System;
using System.Collections.Generic;
using System.Text;

namespace KeeGen.Crypto.Bitcoin
{
    public class KeysInfo
    {
        public string PrivateKey { get; set; }
        public string PublicKey { get; set; }
        public string Address { get; set; }


    }
}