﻿using NBitcoin;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace KeeGen.Crypto.Bitcoin
{
    public class BitcoinFacade
    {

         public string GenerateWallet()
        {
            Key privateKey = new Key();
            PubKey publicKey = privateKey.PubKey;


          
            var address = publicKey.GetAddress(ScriptPubKeyType.Segwit, Network.TestNet);


            //var publicAddress = publicKey.

            //var hashBytes = NBitcoin.Crypto.Hashes.SHA512(UTF8Encoding.UTF8.GetBytes("hello"));

            //var c = NBitcoin.BIP9Deployments.Format.()

            return "";
        }

        public WalletInfo GenerateHDWallet()
        {

            WalletInfo wallet = new WalletInfo();

            // Other Links
            //https://medium.com/singapore-blockchain-dapps/bitcoin-wallet-in-c-31418758dc7b
            //https://programmingblockchain.gitbook.io/programmingblockchain/key_generation/bip_32
            //https://github.com/libbitcoin/libbitcoin-explorer/wiki/Wallet-Commands

            // You can verify this stuff using
            // Colemand Tool  = 


            // ///////////////////////////////////////////////////////////////
            //  Generate BIP39 passPhrase
            //////////////////////////////////////////////////////////////////
            const string passPhrase = "write sketch marriage door output music airport script fossil feel village desk";
            Mnemonic mnemonic = new Mnemonic(passPhrase, Wordlist.English);
            wallet.Words = passPhrase.Split(' ');

            // BIP39 Seed
            var bip39Seed = mnemonic.DeriveSeed();
            var bip39SeetHex = BitConverter.ToString(bip39Seed);



            // BIP32 Get xPriv / xPriv as the root keys
            // Get the HD Root Key (an extended key all others derive from)
            ExtKey xPrivExtKey = mnemonic.DeriveExtKey();
            PubKey xPubKey = xPrivExtKey.GetPublicKey();
            wallet.xPriv = BitConverter.ToString(xPrivExtKey.ToBytes());
            wallet.xPub = BitConverter.ToString(xPubKey.ToBytes());

            // Private keys are often represented in Base58Check called a Bitcoin Secret (also known as Wallet Import Format or simply WIF),
            // like Bitcoin Addresses.
            var xPrivHex = xPrivExtKey.PrivateKey.GetBitcoinSecret(Network.Main).PrivateKey.ToHex();
            BitcoinSecret hdRootHexSecret = xPrivExtKey.PrivateKey.GetBitcoinSecret(Network.Main);
            var xPrivHex2 = BitConverter.ToString(xPrivExtKey.ToBytes());


            for (int i = 0; i < 5; i++)
            {
                Key key = xPrivExtKey.Derive(i);
                Key pubKey = key.PubKey.Derivate()

            }

            //// ROOT
            //var masterKey = hdRoot.PrivateKey
            //var masterPubKey = hdRoot.GetPublicKey();

            //// Depth 1    WALLET ACCOUNTS
            //var key0 = masterKey.Derivate(0);
            //var pubKey0 = masterPubKey.Derivate(0);


            //var key1 = masterKey.Derivate(1);
            //var pubKey1 = masterPubKey.Derivate(1);

            //var key2 = masterKey.Derivate(2);
            //var pubKey2 = masterPubKey.Derivate(2);


            //// m/0/0 Dept 2    // WALLET CHAIN
            //var key00 = key0.Derivate(0);
            //var pubKey00 = pubKey0.Derivate(0);

            //var key01 = key0.Derivate(1);
            //var pubKey01 = pubKey0.Derivate(1);
        
            //var key02 = key0.Derivate(2);
            //var pubKey02 = pubKey0.Derivate(2);

            //var key03 = key0.Derivate(3);
            //var pubKey03 = pubKey0.Derivate(3);


            //// m/0/0/0  Depth 3  ADDRESSES
            //var key000 = key00.Derivate(0);
            //var pubKey000 = pubKey00.Derivate(0);








            // Generate Child Key Pairs
            Console.WriteLine("Master Root key : " + xPrivExtKey.ToString(Network.Main));
            for (int i = 0; i < 5; i++)
            {
                ExtKey key = xPrivExtKey.Derive((uint)i);
                PubKey pubKey = key.GetPublicKey();
                BitcoinAddress address = pubKey.GetAddress(ScriptPubKeyType.Segwit, Network.Main);
                Debug.WriteLine($"{i} Address:{address}  PublicKey:{pubKey} PrivateKey: {key.ToString(Network.Main)}");
            }



            // var bitcoin = new Bitcoin();








            // Derive a Key (not ExtKey) as a child of the root HD
            //Key privateKey = hdRoot.Derive(KeyPath.)


            //  ExtPubKey masterPubKey = masterKey.Neuter();
            //The payment server generate pubkey1
            //  ExtPubKey pubkey1 = masterPubKey.Derive((uint)1);
            //You get the private key of pubkey1
            // ExtKey key1 = masterKey.Derive((uint)1);





            //   BitcoinAddress pubAddress = pubkey1.PubKey.GetAddress(ScriptPubKeyType.Legacy, Network.Main);
            //  BitcoinAddress pubAddress2 = key1.PrivateKey.PubKey.GetAddress(ScriptPubKeyType.Legacy, Network.Main);
            //  var priv = key1.

            //Debug.WriteLine($"Master Key: {masterKey.PrivateKey.ToString()}"); ;
            //Debug.WriteLine($"Master PubKey: {masterPubKey.PubKey.ToString()}"); ;
            //Debug.WriteLine($"Master PubKey Derived: {pubkey1.PubKey.ToString()}"); 
            //Debug.WriteLine($"Master Derived Key: {key1.PrivateKey.ToString()}"); ;
            //  Debug.WriteLine($"public Address: {pubAddress.ToString()}"); ;


            return wallet;

        }

    }
}
