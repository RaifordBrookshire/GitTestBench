﻿using KeeGen.Crypto.Bitcoin;

namespace KeeGen.Crypto.UnitTests.Bitcoin
{
    public class BitcoinFacadeTests
    {

        [Fact]
        public void BasicUsage_Test()
        {
            BitcoinFacade facade = new BitcoinFacade();

          // string w = facade.GenerateWallet();

            facade.GenerateHDWallet();  




        }

        [Fact]
        public void Records_Test()
        {
          //  KeeGen.Crypto.Bitcoin

            // Create your records''
            //KeeGen.Crypto.Bitcoin.
            //BitcoinKeyResults results = new BitcoinResults("pub", "priv", "addr");
            


        }
    }
}
