﻿using System.CommandLine;


namespace KeeGen
{
    internal class Program
    {
        static void Main(string[] args)
        {
           
           // RootCommand.

            Console.WriteLine("Hello, World!");
        }
    }
}