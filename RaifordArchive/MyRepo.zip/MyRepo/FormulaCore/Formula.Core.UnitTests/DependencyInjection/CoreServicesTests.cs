﻿using Formula.Core.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Formula.Core.UnitTests.DependencyInjection
{
    public class CoreServicesTests
    {
        [Fact]
        public void BasicUsage()
        {
            // Setup in Application Start up code
          // CoreServices.ServiceProvider = new ServiceProvider.

            // Get a Service
          // CoreServices.GetService<IServiceProvider>();

        }

    }
}
