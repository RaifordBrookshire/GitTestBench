﻿using Formula.Cryptography.Utils;
using System.Collections.Generic;
using System.Text;
using Xunit;


namespace Formula.Cryptography.UnitTests
{
    public class TestBase
    {
        // Add any common functionality here
    }
}
