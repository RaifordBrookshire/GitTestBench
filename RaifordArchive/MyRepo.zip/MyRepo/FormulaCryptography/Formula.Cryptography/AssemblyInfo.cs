﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Formula.Cryptography.UnitTests.Utils")]

