﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CryptoTools.Cryptography.UnitTests.Asymmetric
{
	[TestClass]
	public class AsymmetricEncryptorTests
	{
		[TestMethod]
		public void TestMethod1()
		{
		}
	}
}
