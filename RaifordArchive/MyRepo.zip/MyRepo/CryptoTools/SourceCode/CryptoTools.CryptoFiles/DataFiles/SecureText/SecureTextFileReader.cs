﻿using System;

namespace CryptoTools.CryptoFiles.DataFiles.SecureTextFiles
{
	public class SecureTextFileReader : IDisposable
	{
		public void Dispose()
		{
			throw new NotImplementedException();
		}
	}
}
