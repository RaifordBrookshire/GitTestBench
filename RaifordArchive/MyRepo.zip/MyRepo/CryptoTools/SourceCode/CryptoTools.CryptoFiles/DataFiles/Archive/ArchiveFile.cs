﻿namespace CryptoTools.CryptoFiles.DataFiles.Archive
{
	class ArchiveFile
	{
	}
}
